My Lesson Buddy Character Studio
character.png is a transparent sticker. character.json records the parts and name.
The files contain no executable code. Original saved characters are immutable.
